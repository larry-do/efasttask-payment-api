package com.nl.controller;

import com.nl.entity.input.RequestCheckOrder;
import com.nl.entity.input.RequestInfo;
import com.nl.entity.output.ResponseCheckOrder;
import com.nl.entity.output.ResponseInfo;
import com.nl.gateway.Gateway;

/**
 *
 * @author TaiND
 */
public class PaymentController {
    
    public ResponseInfo createProfile(String bankCode, String fullName, String email, String mobile, String paymentMethod) throws Exception {
        Gateway alepayGateway = new Gateway();
        RequestInfo input = clonePayment(bankCode, fullName, email, mobile, paymentMethod);
        ResponseInfo responseCreate = alepayGateway.chage(input);
        return responseCreate;
    }
    
    public ResponseCheckOrder checkOrder(String token) throws Exception {
        Gateway alepayGateway = new Gateway();
        RequestCheckOrder input = cloneCheckOrder(token);
        ResponseCheckOrder responseCheckOrder = alepayGateway.checkOrder(input);
        return responseCheckOrder;
    }
    
    private RequestCheckOrder cloneCheckOrder(String token){
        RequestCheckOrder request = new RequestCheckOrder();
        request.setFuntion("GetTransactionDetail");
        request.setVersion("3.1");
        request.setMerchant_id("30439");
        request.setMerchant_password("212325");
        request.setToken(token);
        return request;
    }

    private RequestInfo clonePayment(String bankCode, String fullName, String email, String mobile, String paymentMethod) {
        RequestInfo payment = new RequestInfo();
        try {
            payment.setFuntion("SetExpressCheckout");
            payment.setVersion("3.1");
            payment.setPayment_method(paymentMethod);
            payment.setMerchant_id("30439");
            payment.setMerchant_password("212325");
            payment.setReceiver_email("nguyencamhue@gmail.com");
            payment.setCur_code("vnd");
            payment.setBank_code(bankCode);
            payment.setOrder_code("ma_don_hang01");
            payment.setTotal_amount("2000");
            payment.setFee_shipping("0");
            payment.setDiscount_amount("0");
            payment.setTax_amount("0");
            payment.setOrder_description("Thanh toan tes thu dong hang");
            payment.setReturn_url("http://localhost:8081/return.jsp");
            payment.setCancel_url("http://localhost:8081/cancel.jsp");
            payment.setBuyer_fullname(URLEncoder.encode(fullName, "UTF-8"));
            payment.setBuyer_email(email);
            payment.setBuyer_mobile(mobile);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return payment;
    }
}
